"""
gradebook.py
Defines the Gradebook class, which connects Students, Courses,
Assessments, and Grades together.

Creative feature 1: Letter grades (get_letter_grade)
Creative feature 2: Ranking (show_ranking)
"""


class Gradebook:
    def __init__(self, passing_grade=55):
        self._students = {}     # student_id -> Student object
        self._courses = {}      # course_code -> Course object
        self._grades = {}       # student_id -> {course_code: {assessment_title: score}}
        self._passing_grade = passing_grade

    # ---------------------------------------------------------------
    # Student management
    # ---------------------------------------------------------------
    def add_student(self, student):
        if student.get_id() in self._students:
            print(f"A student with ID {student.get_id()} already exists.")
            return False
        self._students[student.get_id()] = student
        self._grades[student.get_id()] = {}
        print(f"Student {student.get_name()} added successfully.")
        return True

    def view_students(self):
        if not self._students:
            print("No students in the system yet.")
            return
        for student in self._students.values():
            student.display_info()
            print("-" * 30)

    def search_student(self, keyword):
        """Searches for students by ID or name (case-insensitive substring match)."""
        keyword = keyword.lower()
        results = [
            s for s in self._students.values()
            if keyword in s.get_id().lower() or keyword in s.get_name().lower()
        ]
        return results

    def delete_student(self, student_id):
        if student_id not in self._students:
            print("Student ID not found.")
            return False
        student = self._students[student_id]
        # remove the student from any enrolled courses
        for course_code in student.get_courses():
            course = self._courses.get(course_code)
            if course:
                course.remove_student(student_id)
        del self._students[student_id]
        self._grades.pop(student_id, None)
        print(f"Student {student_id} deleted.")
        return True

    # ---------------------------------------------------------------
    # Course management
    # ---------------------------------------------------------------
    def add_course(self, course):
        if course.get_code() in self._courses:
            print(f"A course with code {course.get_code()} already exists.")
            return False
        self._courses[course.get_code()] = course
        print(f"Course {course.get_name()} added successfully.")
        return True

    def enroll_student(self, student_id, course_code):
        student = self._students.get(student_id)
        course = self._courses.get(course_code)
        if not student:
            print("Student not found.")
            return False
        if not course:
            print("Course not found.")
            return False
        student.enroll_course(course_code)
        course.add_student(student_id)
        self._grades[student_id].setdefault(course_code, {})
        print(f"{student.get_name()} enrolled in {course.get_name()}.")
        return True

    # ---------------------------------------------------------------
    # Assessment / grade management
    # ---------------------------------------------------------------
    def add_assessment(self, course_code, assessment):
        course = self._courses.get(course_code)
        if not course:
            print("Course not found.")
            return False
        course.add_assessment(assessment)
        print(f"{assessment.get_title()} added to {course.get_name()}.")
        return True

    def record_grade(self, student_id, course_code, assessment_title, score):
        student = self._students.get(student_id)
        course = self._courses.get(course_code)
        if not student or not course:
            print("Student or course not found.")
            return False
        if course_code not in student.get_courses():
            print(f"{student.get_name()} is not enrolled in {course_code}.")
            return False
        assessment = course.find_assessment(assessment_title)
        if not assessment:
            print("Assessment not found in this course.")
            return False
        if score < 0 or score > assessment.get_max_score():
            print(f"Invalid score. Must be between 0 and {assessment.get_max_score()}.")
            return False
        self._grades.setdefault(student_id, {}).setdefault(course_code, {})
        self._grades[student_id][course_code][assessment_title] = score
        print(f"Recorded {score}/{assessment.get_max_score()} for "
              f"{student.get_name()} in {assessment_title}.")
        print(assessment.grade_message(score))
        return True

    def calculate_average(self, student_id, course_code):
        """Calculates the average PERCENTAGE grade of one student in one course."""
        course = self._courses.get(course_code)
        student_grades = self._grades.get(student_id, {}).get(course_code, {})
        if not course or not student_grades:
            return 0.0
        percentages = []
        for title, score in student_grades.items():
            assessment = course.find_assessment(title)
            if assessment:
                percentages.append(assessment.calculate_percentage(score))
        if not percentages:
            return 0.0
        return round(sum(percentages) / len(percentages), 2)

    def get_result(self, average):
        """Returns Passed/Failed based on the passing grade."""
        return "Passed" if average >= self._passing_grade else "Failed"

    # ---------------------------------------------------------------
    # Creative feature 1: Letter grades
    # ---------------------------------------------------------------
    def get_letter_grade(self, average):
        if average >= 90:
            return "A"
        elif average >= 80:
            return "B"
        elif average >= 70:
            return "C"
        elif average >= self._passing_grade:
            return "D"
        else:
            return "F"

    # ---------------------------------------------------------------
    # Reporting
    # ---------------------------------------------------------------
    def show_report(self, student_id):
        student = self._students.get(student_id)
        if not student:
            print("Student not found.")
            return

        print("===== Student Report =====")
        student.display_info()

        for course_code in student.get_courses():
            course = self._courses.get(course_code)
            if not course:
                continue
            print(f"\nCourse: {course_code} - {course.get_name()}")
            grades = self._grades.get(student_id, {}).get(course_code, {})
            if not grades:
                print("  No grades recorded yet.")
                continue
            for title, score in grades.items():
                assessment = course.find_assessment(title)
                if assessment:
                    pct = assessment.calculate_percentage(score)
                    print(f"  {title}: {score}/{assessment.get_max_score()} = {pct}%")
            average = self.calculate_average(student_id, course_code)
            letter = self.get_letter_grade(average)
            result = self.get_result(average)
            print(f"  Average: {average}%  |  Letter Grade: {letter}  |  Result: {result}")

    # ---------------------------------------------------------------
    # Creative feature 2: Ranking
    # ---------------------------------------------------------------
    def show_ranking(self, course_code):
        """Shows students in a course ranked from highest to lowest average."""
        course = self._courses.get(course_code)
        if not course:
            print("Course not found.")
            return
        rankings = []
        for student_id in course.get_students():
            student = self._students.get(student_id)
            if not student:
                continue
            average = self.calculate_average(student_id, course_code)
            rankings.append((student.get_name(), average))
        rankings.sort(key=lambda x: x[1], reverse=True)

        print(f"===== Ranking for {course_code} - {course.get_name()} =====")
        if not rankings:
            print("No students with grades in this course yet.")
            return
        for position, (name, average) in enumerate(rankings, start=1):
            print(f"{position}. {name} - {average}% ({self.get_letter_grade(average)})")

    # ---------------------------------------------------------------
    # Simple lookups used by the menu
    # ---------------------------------------------------------------
    def get_student(self, student_id):
        return self._students.get(student_id)

    def get_course(self, course_code):
        return self._courses.get(course_code)
